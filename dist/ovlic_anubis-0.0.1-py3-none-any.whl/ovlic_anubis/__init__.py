
__version__ = "0.0.1"
__author__ = "ovlic"

from crypt_backend import encrypt, decrypt